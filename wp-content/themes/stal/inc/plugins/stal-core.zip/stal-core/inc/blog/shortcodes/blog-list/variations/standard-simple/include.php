<?php

include_once 'standard-simple.php';
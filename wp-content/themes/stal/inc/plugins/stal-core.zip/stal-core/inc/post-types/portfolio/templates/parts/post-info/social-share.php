<div class="qodef-e qodef-portfolio-social-share">
	<?php
	$params           = array();
	$params['layout'] = 'list';
	echo StalCoreSocialShareShortcode::call_shortcode( $params );
	?>
</div>
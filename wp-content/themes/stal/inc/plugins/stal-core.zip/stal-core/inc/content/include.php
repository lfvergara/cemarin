<?php

include_once STAL_CORE_INC_PATH . '/content/helper.php';
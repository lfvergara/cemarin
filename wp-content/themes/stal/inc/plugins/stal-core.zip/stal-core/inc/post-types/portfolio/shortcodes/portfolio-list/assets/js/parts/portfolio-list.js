(function ($) {
	
    "use strict";
	qodefCore.shortcodes.stal_core_portfolio_list = {};
	qodefCore.shortcodes.stal_core_portfolio_list.qodefPagination = qodef.qodefPagination;
	qodefCore.shortcodes.stal_core_portfolio_list.qodefFilter = qodef.qodefFilter;
	qodefCore.shortcodes.stal_core_portfolio_list.qodefJustifiedGallery = qodef.qodefJustifiedGallery;
	qodefCore.shortcodes.stal_core_portfolio_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.stal_core_portfolio_list.qodefSwiper = qodef.qodefSwiper;

})(jQuery);
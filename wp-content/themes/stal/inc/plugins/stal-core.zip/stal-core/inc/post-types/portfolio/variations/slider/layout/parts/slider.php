<div class="qodef-media qodef-portfolio-single-slider qodef-swiper-container" data-options='{"slidesPerView":"1"}'>
    <div class="swiper-wrapper">
		<?php stal_core_template_part( 'post-types/portfolio', 'templates/parts/post-info/media', 'slider'); ?>
    </div>
    <div class="swiper-pagination"></div>
</div>
<?php

include_once STAL_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/minimal/minimal.php';
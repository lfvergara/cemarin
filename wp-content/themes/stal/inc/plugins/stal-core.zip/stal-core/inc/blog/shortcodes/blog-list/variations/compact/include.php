<?php

include_once 'compact.php';
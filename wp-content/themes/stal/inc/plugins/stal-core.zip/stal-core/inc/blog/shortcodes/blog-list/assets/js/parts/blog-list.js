(function ($) {
	
    "use strict";
	qodefCore.shortcodes.stal_core_blog_list = {};
	qodefCore.shortcodes.stal_core_blog_list.qodefPagination = qodef.qodefPagination;
	qodefCore.shortcodes.stal_core_blog_list.qodefFilter = qodef.qodefFilter;
	qodefCore.shortcodes.stal_core_blog_list.qodefJustifiedGallery = qodef.qodefJustifiedGallery;
	qodefCore.shortcodes.stal_core_blog_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.stal_core_blog_list.qodefSwiper = qodef.qodefSwiper;

})(jQuery);
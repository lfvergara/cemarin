<?php

include_once STAL_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';
<?php

include_once STAL_CORE_INC_PATH . '/header/layouts/centered/helper.php';
include_once STAL_CORE_INC_PATH . '/header/layouts/centered/centered-header.php';
include_once STAL_CORE_INC_PATH . '/header/layouts/centered/dashboard/admin/centered-header-options.php';
include_once STAL_CORE_INC_PATH . '/header/layouts/centered/dashboard/meta/centered-header-meta.php';
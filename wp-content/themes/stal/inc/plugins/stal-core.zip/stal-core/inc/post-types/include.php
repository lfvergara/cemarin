<?php

include_once STAL_CORE_CPT_PATH . '/post-types.php';
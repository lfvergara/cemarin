<?php

include_once 'standard-no-image.php';